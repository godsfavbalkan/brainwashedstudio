# Brainwashed Studio — one-page portfolio

A responsive static website built with plain HTML, CSS and JavaScript. It is designed for free hosting with GitHub Pages.

## Before publishing
1. Replace the sample work tiles in `index.html` with your real projects, thumbnails and descriptions.
2. Change `hello@brainwashed.studio` to your preferred contact email.
3. Add your Instagram / Vimeo / YouTube links if you want them in the footer.
4. The supplied logo is in `assets/brainwashed-studio-logo.png`.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository named `brainwashed-studio` (or any name you prefer).
2. Upload the contents of this folder — `index.html`, `style.css`, `script.js`, and the `assets` folder — to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. GitHub will publish the site and show its public URL in the Pages section. It may take a few minutes.

No build tools, paid hosting, or framework are required.

## Notes
- Google Fonts are loaded from Google Fonts; the site falls back to Georgia and Arial if unavailable.
- GitHub Pages hosting is free for public repositories.
- The contact button currently uses a mailto link; replace it with your preferred address.
